//
// Created by Radovan Šťastný on 09.03.2026.
//

#include "App.h"

#include <Engine/Log/Log.h>

#include "DebugBreaks.h"
#include "EventHandler.h"

static App* Application = nullptr;

App::App(const Specifications &AppSpec)
{
    Application = this;
    Log::Initialize();
    AppSpecification = AppSpec;
    FrameCounter = 0;
    AppWindow = Window::Create(AppSpec.WindowSpecs);
    AppRenderer = Renderer::Create(*AppWindow);
    Running = true;
}

App::~App()
{

}

void App::Run()
{
    Assert(LevelToTransitionTo != nullptr);

    float LastTime = GetTime();
    while(Running)
    {
        const float CurrentTime = GetTime();
        float DeltaTime = CurrentTime - LastTime;
        LastTime = CurrentTime;
        TryToTransitionToLevel();
        EventHandler::PollInputs();
        if(EventHandler::ShouldStop())
        {
            Stop();
            break;
        }
        CurrentLevel->OnUpdate(DeltaTime);
        AppRenderer->BeginFrame();
        CurrentLevel->OnRender(*AppRenderer);
        AppRenderer->EndFrame();
        FrameCounter++;
    }
}

void App::Stop()
{
    Running = false;
}

App& App::Get()
{
    if (Application == nullptr)
        Assert("Called get on app before it was constructed");

    return *Application;
}

float App::GetTime()
{
    return static_cast<float>(SDL_GetTicks()) / 1000.0f;
}

void App::TryToTransitionToLevel()
{
    if(LevelToTransitionTo)
    {
        if(CurrentLevel)
        {
            CurrentLevel->OnExit();
            CurrentLevel.reset();
        }
        CurrentLevel = std::move(LevelToTransitionTo);
        CurrentLevel->OnEnter();
    }
}

Level * App::GetCurrentLevel() const
{
    return CurrentLevel.get();
}

void App::PrintInfo()
{
    LOG_INFO("Info about app:");
    LOG_INFO("So far no info.");
}
